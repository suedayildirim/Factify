export type Finding = {
  title: string;
  explanation: string;
  excerpt?: string;
  severity?: number;
};

export type ScoreDetail = {
  label: string;
  points: number;
};

export type AnalyzeResponse = {
  score: number;
  language: Finding[];
  logic: Finding[];
  context: Finding[];
  emotion: Finding[];
  details: ScoreDetail[];
  riskLabel?: string;
};

export type AnalyzeHistoryItem = {
  at: number;
  score: number;
  preview: string;
  text: string;
};
