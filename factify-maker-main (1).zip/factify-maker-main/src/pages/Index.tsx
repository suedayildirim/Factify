import { useAnalyze } from "@/hooks/useAnalyze";
import TrustMeter from "@/components/TrustMeter";
import FindingsCard from "@/components/FindingsCard";
import AnalysisHistory from "@/components/AnalysisHistory";
import LoadingSkeleton from "@/components/LoadingSkeleton";
import { Search, AlertTriangle, Shield } from "lucide-react";

export default function Index() {
  const {
    text, setText, loading, error, result,
    history, canAnalyze, analyze, clearHistory, loadFromHistory,
  } = useAnalyze();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            <h1 className="font-display text-xl font-bold text-foreground tracking-tight">
              Fact<span className="text-primary">ify</span>
            </h1>
          </div>
          <p className="text-xs text-muted-foreground hidden sm:block">
            Doğrula · Analiz Et · Öğren
          </p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Hero */}
        <section className="text-center space-y-3">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground">
            Bilgiyi <span className="text-primary">doğrula</span>, güvenle paylaş
          </h2>
          <p className="text-muted-foreground text-sm max-w-xl mx-auto leading-relaxed">
            Şüpheli haberleri ve iddiaları yapay zeka ile analiz edin. Dil manipülasyonu, mantıksal tutarsızlık ve kaynak güvenilirliğini anında değerlendirin.
          </p>
        </section>

        {/* Input Area */}
        <div
          className="rounded-xl border border-border bg-card p-5 space-y-4"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Analiz etmek istediğiniz haber veya iddiayı buraya yapıştırın... (en az 20 karakter)"
            className="w-full h-36 bg-secondary/30 border border-border rounded-lg p-4 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/40 transition-shadow font-body"
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              {text.length} karakter
            </span>
            <button
              onClick={analyze}
              disabled={!canAnalyze}
              className={`
                flex items-center gap-2 px-6 py-2.5 rounded-lg font-display text-sm font-semibold transition-all
                ${canAnalyze
                  ? "bg-primary text-primary-foreground hover:opacity-90 animate-pulse-glow"
                  : "bg-secondary text-muted-foreground cursor-not-allowed"
                }
              `}
            >
              <Search className="w-4 h-4" />
              {loading ? "Analiz ediliyor..." : "Analiz Başlat"}
            </button>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 flex items-start gap-3 animate-fade-up">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {/* Loading */}
        {loading && <LoadingSkeleton />}

        {/* Results */}
        {result && !loading && (
          <div className="space-y-4">
            <TrustMeter score={result.score} riskLabel={result.riskLabel} />

            {/* Analysis Details */}
            {result.details && result.details.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-5 animate-fade-up" style={{ boxShadow: "var(--shadow-card)" }}>
                <h3 className="font-display text-sm font-semibold text-foreground mb-3">📊 Analiz Detayları</h3>
                <ul className="space-y-1.5">
                  {result.details.map((d, i) => (
                    <li key={i} className="flex items-center justify-between text-xs">
                      <span className="text-secondary-foreground">{d.label}</span>
                      <span className={`font-mono font-semibold ${d.points >= 0 ? "text-score-high" : "text-score-low"}`}>
                        {d.points >= 0 ? `+${d.points}` : d.points}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <FindingsCard title="Dil Analizi" icon="🗣️" items={result.language} category="language" />
              <FindingsCard title="Duygu Analizi" icon="💔" items={result.emotion} category="language" />
              <FindingsCard title="Mantık Kontrolü" icon="🧠" items={result.logic} category="logic" />
              <FindingsCard title="Bağlamsal Doğrulama" icon="🔍" items={result.context} category="context" />
            </div>
          </div>
        )}

        {/* History */}
        {!loading && (
          <AnalysisHistory history={history} onSelect={loadFromHistory} onClear={clearHistory} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6 text-center">
          <p className="text-xs text-muted-foreground">
            Factify — Yapay Zeka Destekli Bilgi Doğrulama Asistanı
          </p>
        </div>
      </footer>
    </div>
  );
}
